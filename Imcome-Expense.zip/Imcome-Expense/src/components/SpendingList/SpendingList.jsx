import SpendingItem from "./SpendingItem/SpendingItem";
import "./SpendingList.css";

function SpendingList(props) {
  const filterList = props.filterList;

  return (
    <div>
      {filterList.length === 0 ? (
        <div className="divNotFound">
          <div>Not found</div>
          <code>(╥﹏╥)</code>
        </div>
      ) : (
        filterList.map((e) => (
          <SpendingItem
            editHandler={props.editHandler}
            deleteHandler={props.deleteHandler}
            key={e.id}
            id={e.id}
            type={e.type}
            category={e.category}
            payment={e.payment}
            amount={e.amount}
          />
        ))
      )}
    </div>
  );
}

export default SpendingList;
