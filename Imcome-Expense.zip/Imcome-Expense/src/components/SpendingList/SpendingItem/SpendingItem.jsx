import { useContext, useState } from "react";
import "./SpendingItem.css";
import "@fortawesome/fontawesome-free/css/all.min.css";
import { HandlerContext } from "../../../Contexts/handlerContext";

function SpendingItem(props) {
  const ctx = useContext(HandlerContext);
  let type = props.type;
  let category = props.category;
  let payment = props.payment;
  let amount = props.amount;
  const [isEdit, setIsEdit] = useState(false);
  const [curType, setCurType] = useState("");
  const [curCategory, setCurCategory] = useState("");
  const [curPayment, setCurPayment] = useState("");
  const [curAmount, setCurAmount] = useState("");

  const onClickEdit = () => {
    setIsEdit(true);
    setCurType(type);
    setCurCategory(category);
    setCurPayment(payment);
    setCurAmount(amount);
  };

  const onClickDone = () => {
    const editValues = {
      id: props.id,
      type: curType,
      category: curCategory,
      payment: curPayment,
      amount: curAmount,
    };
    ctx.editHandler(props.id, editValues);
    console.log(props.id);
    setIsEdit(false);
  };

  if (isEdit) {
    return (
      <div className="edit-container">
        <div className="input-container">
          <div>
            <select
              className="select-input"
              value={curType}
              onChange={(e) => setCurType(e.target.value)}
            >
              <option value="Income">Income</option>
              <option value="Expense">Expense</option>
            </select>
          </div>
          <div>
            <select
              className="select-input"
              value={curCategory}
              onChange={(e) => setCurCategory(e.target.value)}
            >
              <option value="Food">Food</option>
              <option value="Clothing">Clothing</option>
              <option value="Personal Item">Personal Item</option>
              <option value="Transport">Transport</option>
              <option value="Travel">Travel</option>
              <option value="Salary">Salary</option>
              <option value="Freelance">Freelance</option>
              <option value="Additional career">Additional career</option>
              <option value="Other">Other</option>
            </select>
          </div>
          <div>
            <select
              className="select-input"
              value={curPayment}
              onChange={(e) => setCurPayment(e.target.value)}
            >
              <option value="Cash">Cash</option>
              <option value="Credit">Credit</option>
              <option value="Bank Account">Bank Account</option>
            </select>
          </div>
          <div>
            <input
              className="inputStyle"
              type="text"
              placeholder="Your amount."
              value={curAmount}
              onChange={(e) => setCurAmount(e.target.value)}
            />
          </div>
        </div>
        <div>
          <button className="btn-Done" onClick={onClickDone}>
          <i className="fa-regular fa-circle-check icon"></i>
            Done
          </button>
        </div>
        <div>
          <button className="btn-Cancle" onClick={() => setIsEdit(false)}>
          <i className="fa-regular fa-rectangle-xmark icon"></i>
            Cancle
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="SpendingItem">
      <div>{type}</div>
      <div>{category}</div>
      <div>{payment}</div>
      <div>{amount}</div>
      <div>
        <button className="btn-edit" onClick={onClickEdit}>
        <i className="fa-solid fa-pen-to-square icon"></i>
          Edit
        </button>
      </div>
      <div>
        <button
          className="btn-delete"
          onClick={() => ctx.deleteHandler(props.id)}
        >
          <i className="fa-regular fa-trash-can icon"></i>
          Delete
        </button>
      </div>
    </div>
  );
}

export default SpendingItem;
