import { useContext, useState } from "react";
import "./NewList.css";
import "@fortawesome/fontawesome-free/css/all.min.css";
import { HandlerContext } from "../../Contexts/handlerContext";

function NewList(props) {
  const ctx=useContext(HandlerContext);
  const setIsShow = props.setIsShow;
  const [type, setType] = useState("Income");
  const [category, setCategory] = useState("Food");
  const [payment, setPayment] = useState("Cash");
  const [amount, setAmount] = useState("");

  const clickHandler = () => {
    const newList = {
      type: type,
      category: category,
      payment: payment,
      amount: amount,
    };

    ctx.addNewList(newList);

    setType("Income");
    setCategory("Food");
    setPayment("Cash");
    setAmount("");
    setIsShow(false);
  };

  return (
    <div className="New-List">
      <div className="formInput">
        <div className="select-control">
          <label>Type</label>
          <select
            className="select-NewList"
            value={type}
            onChange={(event) => setType(event.target.value)}
          >
            <option value="Income">Income</option>
            <option value="Expense">Expense</option>
          </select>
        </div>
        <div>
          <label>Category</label>
          <select
            className="select-NewList"
            value={category}
            onChange={(event) => setCategory(event.target.value)}
          >
            <option value="Food">Food</option>
            <option value="Clothing">Clothing</option>
            <option value="Personal Item">Personal Item</option>
            <option value="Transport">Transport</option>
            <option value="Travel">Travel</option>
            <option value="Salary">Salary</option>
            <option value="Freelance">Freelance</option>
            <option value="Additional career">Additional career</option>
            <option value="Other">Other</option>
          </select>
        </div>
        <div>
          <label>Payment</label>
          <select
            className="select-NewList"
            value={payment}
            onChange={(event) => setPayment(event.target.value)}
          >
            <option value="Cash">Cash</option>
            <option value="Credit">Credit</option>
            <option value="Bank Account">Bank Account</option>
          </select>
        </div>
        <div>
          <label>Amount</label>
          <input
            className="inputNewList"
            type="text"
            placeholder="Your amount."
            value={amount}
            onChange={(event) => setAmount(event.target.value)}
          />
        </div>
      </div>
      <div className="btnGroup">
        <div className="divAddBtn">
          <button className="Add-button" onClick={clickHandler}>
            <i className="fa-solid fa-plus icon"></i>Add
          </button>
        </div>
        <div className="divCancleBtn">
          <button className="Cancle-button" onClick={() => setIsShow(false)}>
          <i className="fa-solid fa-xmark icon"></i>
            Cancle
          </button>
        </div>
      </div>
    </div>
  );
}

export default NewList;
