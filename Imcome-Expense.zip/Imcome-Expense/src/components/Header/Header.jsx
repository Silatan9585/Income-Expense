import React from "react";
import "./Header.css";



function Header({ value, onChange }) {
    
    return (
        <div className="container-header">
            <div className="label-header">
                Filter :
            </div>
            <select value={value} onChange={onChange} className="select-header">
                <option value="Income">Income</option>
                <option value="Expense">Expense</option>
            </select>
        </div>

    )
}

export default Header;
