import { createContext } from "react";

export const HandlerContext = createContext({
    addNewList: (newList) =>{},
    deleteHandler: (id) => {},
    editHandler: (id, list) => {},
});