import { useEffect, useReducer, useState } from "react";
import "./App.css";
import SpendingList from "./components/SpendingList/SpendingList";
import Header from "./components/Header/Header";
import NewList from "./components/NewList/NewList";
import "@fortawesome/fontawesome-free/css/all.min.css";
import { HandlerContext } from "./Contexts/handlerContext";

let initialId = 4;

function uniqeID() {
  initialId = initialId + 1;
  return initialId;
}
const INITIAL_LIST = [
  {
    id: 1,
    type: "Income",
    category: "Salary",
    payment: "Bank Account",
    amount: 20000,
  },
  {
    id: 2,
    type: "Expense",
    category: "Food",
    payment: "Cash",
    amount: 300,
  },
  {
    id: 3,
    type: "Expense",
    category: "Personal Item",
    payment: "Credit",
    amount: 500,
  },
  {
    id: 4,
    type: "Income",
    category: "Interest",
    payment: "Bank Account",
    amount: 570,
  },
];

function reducer(spendingList, action){
  switch(action.type){
    case "add_spend":
      return [action.newList, ...spendingList];
    case "delete_spend":
      return spendingList.filter((e) => e.id !== action.deleteId);
    case "edit_spend":
      const newList = [...spendingList];

      const idx = spendingList.findIndex((e) => e.id === action.editId);
      newList[idx] = { ...action.list };
      return newList;
    default :
  }
}

function App() {
  const [spendingList, dispatch] = useReducer(reducer, {}, () => {
    const localSpend = localStorage.getItem("spend");
    if(localSpend === null){
      return INITIAL_LIST;
    }
    return JSON.parse(localSpend);
    } )

  const [curType, setCurType] = useState("Income");
  const [isShow, setIsShow] = useState(false);

  const filterList = spendingList.filter((l) => l.type === curType);

  useEffect(()=> {
    localStorage.setItem("spend", JSON.stringify(spendingList));
  }, [spendingList]);

  const addNewList = (newList) => {
    const newListData = {
      ...newList,
      id: uniqeID(),
    };
    dispatch({
      type: "add_spend",
      newList: newListData,
    })
  };

  const editHandler = (id, list) => {
    dispatch({
      type: "edit_spend",
      editId: id,
      list: list,
    })
  };

  const deleteHandler = (id) => {
    dispatch({
      type: "delete_spend",
      deleteId: id,
    })
  };

  return (
    <HandlerContext.Provider value={{
      editHandler: editHandler,
      deleteHandler: deleteHandler,
      addNewList: addNewList,}
    }>
    <div>
      <div>
        <h1>Income Expense</h1>
      </div>
      {isShow ? (
        <NewList setIsShow={setIsShow} />
      ) : (
        <div className="add-btn-container">
          <button className="add-btn" onClick={() => setIsShow(true)}>
          <i className="fa-solid fa-plus icon"></i>
            Add new list
          </button>
        </div>
      )}
      <br />
      <Header value={curType} onChange={(e) => setCurType(e.target.value)} />
      <SpendingList
        filterList={filterList}
        editHandler={editHandler}
        deleteHandler={deleteHandler}
      />
    </div>
    </HandlerContext.Provider>
  );
}

export default App;
